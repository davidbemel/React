import React from 'react';
import StarRatings from 'react-star-ratings';

const InfoLugar = ({googleMaps, img}) => {
   return ( 
      <div className="row">
         <div className="col-12">
          
            <h1 className="text-center">{googleMaps.name}</h1>
         </div>
         <div className="col-12">
            <div className="row">
               <div className="col-12 text-center">
                  <img src={img} alt="" height="200px"/>
               </div>            
            </div>
            <div className="row">
               <div className="col-12 col-lg-4 col-xl-3 mx-auto">
                  <p>{googleMaps.formatted_address}</p>
               </div>
               <div className="col-12">
                  <p> <b className="text-primary">Horario:</b> se encuentra { googleMaps.opening_hours.hasOwnProperty('open_now')? googleMaps.opening_hours.open_now ? 'Abierto': 'Cerrado' :'' }</p>
                  <div>
                     <b>Rating: {googleMaps.rating} </b>
                     <StarRatings
                        rating={googleMaps.rating}
                        starRatedColor="#f7c52b"
                        numberOfStars={5}
                        starDimension="25px"
                        starSpacing="1px"
                        name='rating'
                     />
                  </div>                 
               </div>
               <div className="col-12">
               <iframe width="600" height="450" frameborder="0"
               src={`https://www.google.com/maps/embed/v1/search?q=${googleMaps.name}&key=AIzaSyAdhpX41vhIf0HIqzl0z8T-h6qekqhH1aw`} allowfullscreen />
               </div>
            </div>
            <div className="Direccion">
            
            </div>
         </div>
         <div className="col-12">

         </div>
      </div> 
    );
}
 
export default InfoLugar;

