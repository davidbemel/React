import React from 'react';
import StarRatings from 'react-star-ratings';

const LugarCercano = ({LugaresCercanos, viewLugar}) => {
   return ( <div className="row">      
         {LugaresCercanos.map(Lugar => (
            <div className="col-12 col-md-6 col-xl-4">
               <div className="card my-2">
                  <div className="card-body">
                     <div className="text-center">
                        <img src={`https://maps.googleapis.com/maps/api/place/photo?maxwidth=${Lugar.photos[0].height}&photoreference=${Lugar.photos[0].photo_reference}&key=AIzaSyAdhpX41vhIf0HIqzl0z8T-h6qekqhH1aw`} alt="" className="h50" height="150px"/>
                     </div>
                     <h4> <img src={Lugar.icon} alt="" height="20px"/> {Lugar.name}</h4>
                     <p><b>Direccion:</b> {Lugar.vicinity}</p>
                     <div>
                        <b>Rating: {Lugar.rating} </b>
                        <StarRatings
                           rating={Lugar.rating}
                           starRatedColor="#f7c52b"
                           numberOfStars={5}
                           starDimension="15px"
                           starSpacing="1px"
                           name='rating'
                        />
                     </div>
                     <button type="button" onClick={()=>viewLugar(Lugar.name)} class="btn btn-primary">Ir</button>
                  </div>               
               </div>
            </div> 
            ))
         }          
   </div> 
   );
}
 
export default LugarCercano;