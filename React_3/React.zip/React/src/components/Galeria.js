import React from 'react';
import ReactHtmlParser from 'react-html-parser';

const Galeria = ({foto}) => {
   return ( 
      <div className="col-12 col-md-4 col-lg-3">
         <div> { ReactHtmlParser(foto.html_attributions) }  </div>;
      </div>
    );
}
 
export default Galeria;