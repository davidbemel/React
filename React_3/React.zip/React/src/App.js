import React, { Component } from 'react';

import InfoLugar from './components/InfoLugar';
import LugarCercano from './components/LugarCercano';


const formato = {
  "formatted_address": "",
  "geometry": {
    "location": {
      "lat": '',
      "lng": ''
    },
    "viewport": {
      "northeast": {
        "lat": '',
        "lng": ''
      },
      "southwest": {
        "lat": '',
        "lng": ''
      }
    }
  },
  "name": "",
  "opening_hours": {
    "open_now": ''
  },
  "photos": [
    {
      "height": '',
      "html_attributions": '',
      "photo_reference": '',
      "width": ''
    }
  ],
  "rating": 0
}
class App extends Component {

  token = 'AIzaSyAdhpX41vhIf0HIqzl0z8T-h6qekqhH1aw';
  tmaps = 'AIzaSyAdhpX41vhIf0HIqzl0z8T-h6qekqhH1aw';
  constructor(props) {
    super(props);
    this.state = {
      lugar: '',
      googleMaps: formato,
      LugaresCercanos: []
    }
  }

  obtenerDatosEvento = e => {
    this.setState({
      [e.target.name]: e.target.value
    });
  };

  Consultar = async (e) => {
    e.preventDefault();
    const url = `https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=${this.state.lugar}&inputtype=textquery&fields=photos,icon,formatted_address,name,opening_hours,rating,permanently_closed,geometry&key=${this.token}&locale=es_ES`;

    const proxyurl = "https://cors-anywhere.herokuapp.com/";
    let respuesta = await fetch(proxyurl + url);
    const googleMaps = await respuesta.json();
    if (googleMaps.status === 'ZERO_RESULTS') {
      return alert('No se encuentras lugares con esto nombre');
    }

    const photoreference = googleMaps.candidates[0].photos[0].photo_reference;

    const urlFoto = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=6000&photoreference=${photoreference}&key=
    ${this.token}`;

    this.setState({
      googleMaps: googleMaps.candidates[0],
      LugaresCercanos: [],
      img: urlFoto
    })
  }

  LugaresCercanos = async (e) => {
    e.preventDefault();
    const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${this.state.googleMaps.geometry.location.lat},${this.state.googleMaps.geometry.location.lng}&radius=5000&type=restaurant&&key=${this.token}`;
    const proxyurl = "https://cors-anywhere.herokuapp.com/";
    let respuesta = await fetch(proxyurl + url);
    const LugaresCercanos = await respuesta.json();
    this.setState({
      LugaresCercanos: LugaresCercanos.results
    })
    console.log(this.state)
  }

  viewLugar = async (name) => {
    const url = `https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=${name}&inputtype=textquery&fields=photos,icon,formatted_address,name,opening_hours,rating,permanently_closed,geometry&key=${this.token}&locale=es_ES`;

    const proxyurl = "https://cors-anywhere.herokuapp.com/";
    let respuesta = await fetch(proxyurl + url);
    const googleMaps = await respuesta.json();
    if (googleMaps.status === 'ZERO_RESULTS') {
      return alert('No se encuentras lugares con esto nombre');
    }

    const photoreference = googleMaps.candidates[0].photos[0].photo_reference;

    const urlFoto = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=6000&photoreference=${photoreference}&key=
    ${this.token}`;

    this.setState({
      lugar:name,
      googleMaps: googleMaps.candidates[0],
      LugaresCercanos: [],
      img: urlFoto
    })
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-12">
            .<div className="card">
              <div className="card-body">
              <h3>Busca tu lugar favorito</h3>
                <form onSubmit={this.Consultar}>
                  <div className="input-group mb-3">
                    <input type="text" className="form-control" name="lugar" placeholder="Ingrese Lugar" onChange={this.obtenerDatosEvento} required />
                    <div className="input-group-append">
                      <button type="submit" className="btn btn-outline-secondary" id="button-addon2">Consultar</button>
                    </div>
                  </div>
                </form>
                <InfoLugar googleMaps={this.state.googleMaps} img={this.state.img} />
                <button type="button" className="btn btn-primary my-3" onClick={this.LugaresCercanos}>Buscar Lugares Cercanos</button>
                <LugarCercano LugaresCercanos={this.state.LugaresCercanos} viewLugar={this.viewLugar} />
                <hr />
              </div>
            </div>
          </div>
        </div>
      </div>);
  }
}

export default App;
